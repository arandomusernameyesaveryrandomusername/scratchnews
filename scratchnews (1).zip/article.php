<?php
require_once __DIR__ . '/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
logVisit('/article/' . $id);

$article = $id > 0 ? getArticleById($id) : null;
session_start();

$isBanned = !empty($_SESSION['reader_id']) && isUserBanned($_SESSION['reader_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $article && !empty($_SESSION['reader_id'])) {
    if (($_POST['action'] ?? '') === 'like' && !$isBanned) {
        toggleLike($article['id'], $_SESSION['reader_id']);
        header('Location: /article/' . $article['id']);
        exit;
    }
    if (($_POST['action'] ?? '') === 'comment' && !$isBanned) {
        $content = trim($_POST['content'] ?? '');
        $parentId = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
        if ($content !== '') addComment($article['id'], $_SESSION['reader_id'], $content, $parentId);
        header('Location: /article/' . $article['id']);
        exit;
    }
    if (($_POST['action'] ?? '') === 'report') {
        $commentId = (int)($_POST['comment_id'] ?? 0);
        if ($commentId > 0) reportComment($commentId, $_SESSION['reader_id']);
        header('Location: /article/' . $article['id']);
        exit;
    }
}

$comments = $article ? getCommentsForArticle($article['id']) : [];
$commentTree = $article ? buildCommentTree($comments) : [];
$likeCount = $article ? getLikeCount($article['id']) : 0;
$liked = ($article && !empty($_SESSION['reader_id'])) ? hasUserLiked($article['id'], $_SESSION['reader_id']) : false;

if (!$article) {
    http_response_code(404);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
<title><?= $article ? e($article['title']) . ' - ' . e(SITE_NAME) : 'Article not found' ?></title>
<link rel="stylesheet" href="/assets/style.css?v=2">
</head>
<body>
<header id="siteHeader">
    <a href="/" class="logo-link">
<svg viewBox="0,0,136.90609,31.33279" class="logo-svg" xmlns="http://www.w3.org/2000/svg"><g transform="translate(-172.33195,-164.3336)"><g stroke-miterlimit="10"><text transform="translate(217.16808,185.69599) scale(0.5,0.5)" font-size="40" fill="#ffffff" stroke="#ffaa33" stroke-width="3" font-family="Scratch" font-weight="normal" text-anchor="start"><tspan x="0" dy="0">ScratchNews</tspan></text><text transform="translate(217.16808,185.69599) scale(0.5,0.5)" font-size="40" fill="#ffffff" stroke="none" stroke-width="1" font-family="Scratch" font-weight="normal" text-anchor="start"><tspan x="0" dy="0">ScratchNews</tspan></text><path d="M181.04509,195.64879h-8.71313v-10.6397h8.71313z" fill="#cc8829" stroke="none"/><path d="M176.88045,195.6664v-20.46677l3.90302,-0.07587l0.09189,-5.0222h6.64479v20.71239l-3.91923,0.16783l-0.04923,4.68462z" fill="#ffaa33" stroke="none"/><path d="M201.40189,164.35122h8.71313v10.6397h-8.71313z" fill="#cc8829" stroke="none"/><path d="M205.56653,164.33361v20.46677l-3.90302,0.07587l-0.09189,5.0222h-6.64479v-20.71239l3.91923,-0.16783l0.04923,-4.68462z" fill="#ffaa33" stroke="none"/><path d="M190.06459,189.91166l-0.03808,-3.62362l-3.03158,-0.12982v-16.02128h5.13983l0.07108,3.88473l3.01904,0.05869v15.8313z" fill="#ffaa33" stroke="none"/></g></g></svg>
</a>
<nav>
    <?php if (!empty($_SESSION['reader_username'])): ?>
        <span>Hi, <?= e($_SESSION['reader_username']) ?>!</span>
        <?php if (!empty($_SESSION['is_admin'])): ?>
        <a href="/admin/">Admin</a>
        <?php endif; ?>
        <a href="/logout">Log Out</a>
    <?php else: ?>
        <a href="/login">Log In</a>
        <a href="/register">Sign Up</a>
    <?php endif; ?>
    </nav></header>
<main>
    <a class="back-link" href="/">&larr; Back to all articles</a>
    <?php if ($article): ?>
        <div class="full-article">
            <h1><?= e($article['title']) ?></h1>
            <div class="meta">
                By <?= e($article['author']) ?> ·
                Published <?= date('F j, Y', strtotime($article['created_at'])) ?>
                <?php if ($article['updated_at'] !== $article['created_at']): ?>
                    · Updated <?= date('F j, Y', strtotime($article['updated_at'])) ?>
                <?php endif; ?>
            </div>
            <div class="content"><?= $article['content'] ?></div>
            <div class="likes-section">
    <form method="post">
        <input type="hidden" name="action" value="like">
        <button class="btn" type="submit" <?= (empty($_SESSION['reader_id']) || $isBanned) ? 'disabled' : '' ?>>
            <?= $liked ? '💔 Unlike' : '❤️ Like' ?> (<?= $likeCount ?>)
        </button>
    </form>
    <?php if ($isBanned): ?>
        <p class="meta">Your account is restricted from liking and commenting.</p>
    <?php endif; ?>
</div>
            <div class="comments-section">
    <h3>Comments (<?= count($comments) ?>)</h3>
    <?php if (!empty($_SESSION['reader_id']) && !$isBanned): ?>
        <form method="post">
            <input type="hidden" name="action" value="comment">
            <textarea name="content" placeholder="Add a comment..." required></textarea>
            <button class="btn" type="submit">Post Comment</button>
        </form>
    <?php elseif (!$isBanned): ?>
        <p><a href="/signin">Log in</a> or <a href="/register">sign up</a> to comment.</p>
    <?php endif; ?>
    <?php foreach ($commentTree as $c): ?>
        <?= renderCommentThread($c, !empty($_SESSION['reader_id']) && !$isBanned, 0, !empty($_SESSION['reader_id'])) ?>
    <?php endforeach; ?>
</div>
        </div>
    <?php else: ?>
        <div class="alert error">Article #<?= (int)$id ?> was not found. It may have been removed.</div>
    <?php endif; ?>
</main>
<footer>
    &copy; <?= e(SITE_NAME) ?>
    <?php if (!empty($_SESSION['reader_username'])): ?>
        &middot; <a href="/delete-account">Delete Account</a>
    <?php endif; ?>
    &middot; <a href="/feedback.php">Feedback</a>
</footer>
<script>
    window.addEventListener('scroll', function() {
        var header = document.getElementById('siteHeader');
        if (window.scrollY > 50) {
            header.classList.add('shrink');
        } else {
            header.classList.remove('shrink');
        }
    });
</script>
</body>
</html>